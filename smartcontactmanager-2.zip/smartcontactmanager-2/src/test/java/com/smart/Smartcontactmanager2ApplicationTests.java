package com.smart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Smartcontactmanager2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
